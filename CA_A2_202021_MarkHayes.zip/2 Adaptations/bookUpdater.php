<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='adaptations';
$connA=mysqli_connect($host,$user,$pass,$db);

$bookName=$_POST['BookName'];
$bookID=$_POST['BookID'];
$author=$_POST['Author'];
$publicationYear=$_POST['PublicationYear'];
$pages=$_POST['Pages'];
$movieID=$_POST['MovieID'];

mysqli_query($connA,"INSERT into books VALUES ('$bookName','$bookID','$author','$publicationYear','$pages','$movieID')");
header('Location: books.php');
?>

