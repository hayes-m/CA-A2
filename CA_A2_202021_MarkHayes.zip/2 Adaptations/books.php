<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='adaptations';
$conn=mysqli_connect($host,$user,$pass,$db);
$bookResult=mysqli_query($conn,'select * from books');


?>

<html>
	<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<style>
		body	{
		font-family: "Trebuchet", Arial, sans-serif;
		text-align: center;
		}

		div.border{
		margin: 0 15% 0 15%;
		border-left: 2px solid #262626;
		border-right: 2px solid #262626;
		padding: 5px;
		height: 100%;
		}

		table{
		border-radius:5px;
		border-style:hidden;
		background-color:#F2F3F4;
		}

		th{
		border-radius:5px;
		}

		td{
		text-align:right;
		border-radius:5px;
		}

		.boxes {
		width: 500px;
		clear: both;
		}

		.boxes input{
		border-radius:10px;
		width: 100%;
		clear: both;
		}

		h3{
		text-align:center;
		}

		form{
		width:100%;
		margin-left:50%;
		}

	</style>	

	<img src="https://maxcdn.icons8.com/Share/icon/ios7/Files/open_book1600.png" alt="books" align="left" style="width:150px;height:150px";/>
	<img src="https://maxcdn.icons8.com/Share/icon/ios7/Files/open_book1600.png" alt="books" align="right" style="width:150px;height:150px";/>

	</head>        

	<div class="border">    

<?php

	echo "<table border='2' width='100%'>
	<tr>
	<th>Book ID</th>
	<th>Book name</th>
	<th>Author</th>
	<th>Year of Publication</th>
	<th>Pages</th>
	<th>Movie ID</th>
	</tr>";


	while($mybooks=mysqli_fetch_array($bookResult,MYSQLI_ASSOC))
        {
?>
	<div align="center"


<?php

	echo "<tr>";
	echo "<td>".$mybooks['bookID']."</td>";
	echo "<td>".$mybooks['bookName']."</td>";
	echo "<td>".$mybooks['author']."</td>";
	echo "<td>".$mybooks['publicationYear']."</td>";
	echo "<td>".$mybooks['pages']."</td>";
	echo "<td>".$mybooks['movieID']."</td>";
	echo "</tr>";

?>
	</div>
<?php

	}

	echo "</table>";
?>

	<div class="border">
	<div class="boxes">

		<form action="bookUpdater.php" method="post">
                	<h3>Enter New Book</h3>
		
			<b>Name<input type="text" name="BookName" value="" /></b>
			<br><br>
			<b>Book ID<input type="text" name="BookID" value="" /></b>
			<br><br>
			<b>Author<input type="text" name="Author" value="" /></b>
			<br><br>
			<b>Year of Publication<input type="text" name="PublicationYear" value="" /></b>
			<br><br>
			<b>Number of Pages<input type="text" name="Pages" value="" /></b>
			<br><br>
			<b>Movie ID<input type="text" name="MovieID" value="" /></b>
			<br><br>
			<input type="submit" value="enter" />
		</form>
	</div>
	</div>

</html>
