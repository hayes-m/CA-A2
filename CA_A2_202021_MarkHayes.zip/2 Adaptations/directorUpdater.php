<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='adaptations';
$connA=mysqli_connect($host,$user,$pass,$db);

$directorID=$_POST['DirectorID'];
$directorName=$_POST['DirectorName'];
$country=$_POST['Country'];
$activeFrom=$_POST['ActiveFrom'];
$movieID=$_POST['MovieID'];

mysqli_query($connA,"INSERT into directors (directorID,directorName,country,activeFrom,movieID) VALUES ('$directorID','$directorName','$country','$activeFrom','$movieID')");
header('Location: directors.php');
?>

