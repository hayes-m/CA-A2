<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='adaptations';
$conn=mysqli_connect($host,$user,$pass,$db);
$directorResult=mysqli_query($conn,'select * from directors');
?>

<html>
	<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<style>
		body	{
		font-family: "Trebuchet", Arial, sans-serif;
		text-align: center;
		}

		div.border{
		margin: 0 15% 0 15%;
		border-left: 2px solid #262626;
		border-right: 2px solid #262626;
		padding: 5px;
		height: 100%;
		}

		table{
		border-radius:5px;
		border-style:hidden;
		background-color:#F2F3F4;
		}

		th{
		border-radius:5px;
		}

		td{
		text-align:right;
		border-radius:5px;
		}

		.boxes {
		width: 500px;
		clear: both;
		}

		.boxes input{
		border-radius:10px;
		width: 100%;
		clear: both;
		}

		h3{
		text-align:center;
		}

		form{
		width:100%;
		margin-left:50%;
		}
		
		.flip{
		-webkit-transform: scaleX(-1);
		transform:scaleX(-1);
		}

	</style>	

		<img src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Ftse1.mm.bing.net%2Fth%3Fid%3DOIP.McJwQOErverBbu6fhkB7nQHaHa%26pid%3DApi&f=1" alt="directors" align="left" style="width:150px;height:150px";/>
	        <img src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Ftse1.mm.bing.net%2Fth%3Fid%3DOIP.McJwQOErverBbu6fhkB7nQHaHa%26pid%3DApi&f=1" alt="directors" align="right" style="width:150px;height:150px";/>

	</head>        

	<div class="border">    

<?php

	echo "<table border='2' width='100%'>
	<tr>
	<th>Director ID</th>
	<th>Director Name</th>
	<th>Country</th>
	<th>Active From</th>
	<th>Movie ID</th>
	</tr>";


	while($mydirectors=mysqli_fetch_array($directorResult,MYSQLI_ASSOC))
        {
?>
	<div align="center"


<?php

	echo "<tr>";
	echo "<td>".$mydirectors['directorID']."</td>";
	echo "<td>".$mydirectors['directorName']."</td>";
	echo "<td>".$mydirectors['country']."</td>";
	echo "<td>".$mydirectors['activeFrom']."</td>";
	echo "<td>".$mydirectors['movieID']."</td>";

	echo "</tr>";

?>
	</div>
<?php

	}

	echo "</table>";
?>

	<div class="border">
	<div class="boxes">

		<form action="directorUpdater.php" method="post">
	                <h3>Enter New Director</h3>

			<b>Director ID<input type="text" name="DirectorID" value="" /></b>
			<br><br>
			<b>Name<input type="text" name="DirectorName" value="" /></b>
			<br><br>
			<b>Country<input type="text" name="Country" value="" /></b>
			<br><br>
			<b>Active From<input type="text" name="ActiveFrom" value="" /></b>
			<br><br>
			<b>Movie ID<input type="text" name="MovieID" value="" /></b>
			<br><br>
			<input type="submit" value="enter" />
		</form>
	</div>
	</div>

</html>


