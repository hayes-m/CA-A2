<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='adaptations';
$conn=mysqli_connect($host,$user,$pass,$db);
$movieResult=mysqli_query($conn,'select * from movies');
?>

<html>
	<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<style>
		body	{
		font-family: "Trebuchet", Arial, sans-serif;
		text-align: center;
		}

		div.border{
		margin: 0 15% 0 15%;
		border-left: 2px solid #262626;
		border-right: 2px solid #262626;
		padding: 5px;
		height: 100%;
		}

		table{
		border-radius:5px;
		border-style:hidden;
		background-color:#F2F3F4;
		}

		th{
		border-radius:5px;
		}

		td{
		text-align:right;
		border-radius:5px;
		}

		.boxes {
		width: 500px;
		clear: both;
		}

		.boxes input{
		border-radius:10px;
		width: 100%;
		clear: both;
		}

		h3{
		text-align:center;
		}

		form{
		width:100%;
		margin-left:50%;
		}
		
		.flip{
		-webkit-transform: scaleX(-1);
		transform:scaleX(-1);
		}

	</style>	

	<img src="http://cdn.onlinewebfonts.com/svg/img_129492.png" alt="movies" align="left" style="width:150px;height:150px";/>
        <img src="https://i.postimg.cc/c4QW4yJZ/img-129492.png alt="movies" align="right" style="width:150px;height:150px";/>

	</head>        

	<div class="border">    

<?php

	echo "<table border='2' width='100%'>
	<tr>
	<th>Movie ID</th>
	<th>Movie name</th>
	<th>Year</th>
	<th>Genre</th>
	<th>Runtime</th>
	<th>Director ID</th>
	<th>Book ID</th>
	</tr>";


	while($mymovies=mysqli_fetch_array($movieResult,MYSQLI_ASSOC))
        {
?>
	<div align="center"


<?php

	echo "<tr>";
	echo "<td>".$mymovies['movieID']."</td>";
	echo "<td>".$mymovies['movieName']."</td>";
	echo "<td>".$mymovies['year']."</td>";
	echo "<td>".$mymovies['genre']."</td>";
	echo "<td>".$mymovies['runtime']."</td>";
	echo "<td>".$mymovies['directorID']."</td>";
	echo "<td>".$mymovies['bookID']."</td>";

	echo "</tr>";

?>
	</div>
<?php

	}

	echo "</table>";
?>

	<div class="border">
	<div class="boxes">

		<form action="movieUpdater.php" method="post">
	                <h3>Enter New Movie</h3>

			<b>Movie ID<input type="text" name="MovieID" value="" /></b>
			<br><br>
			<b>Name<input type="text" name="MovieName" value="" /></b>
			<br><br>
			<b>Year<input type="text" name="Year" value="" /></b>
			<br><br>
			<b>Genre<input type="text" name="Genre" value="" /></b>
			<br><br>
			<b>Runtime<input type="text" name="Runtime" value="" /></b>
			<br><br>
			<b>Director ID<input type="text" name="DirectorID" value="" /></b>
			<br><br>
			<b>Book ID<input type="text" name="BookID" value="" /></b>
			<br><br>
			<input type="submit" value="enter" />
		</form>
	</div>
	</div>

</html>

