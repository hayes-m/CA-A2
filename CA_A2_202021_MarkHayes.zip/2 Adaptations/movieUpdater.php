<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='adaptations';
$connA=mysqli_connect($host,$user,$pass,$db);

$movieID=$_POST['MovieID'];
$movieName=$_POST['MovieName'];
$year=$_POST['Year'];
$genre=$_POST['Genre'];
$runtime=$_POST['Runtime'];
$directorID=$_POST['DirectorID'];
$bookID=$_POST['BookID'];

mysqli_query($connA,"INSERT into movies (movieID,movieName,year,genre,runtime,directorID,bookID) VALUES ('$movieID','$movieName','$year','$genre','$runtime','$directorID','$bookID')");
header('Location: movies.php');
?>
